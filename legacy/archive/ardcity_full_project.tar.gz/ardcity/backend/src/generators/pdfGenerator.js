// PDF Generator using PDFKit (pure Node.js)
import PDFDocument from "pdfkit";

const GOLD="#B8912A",GOLD2="#D4A843",NAVY="#0D1F3C",MIDBLUE="#1A3A6B",STEEL="#2C5282",SLATE="#4A5568",DGRAY="#2D2D2D",LGRAY="#EEF2F8",WHITE="#FFFFFF";

function safe(t){return String(t||"").replace(/[\u2018\u2019]/g,"'").replace(/[\u201C\u201D]/g,'"').replace(/\u2013/g,"-").replace(/\u2014/g,"--");}

class PDFBuilder{
  constructor(){
    this.doc=new PDFDocument({size:"LETTER",margins:{top:58,bottom:68,left:56,right:56},info:{Title:"ARD City Sales Intelligence"},bufferPages:true});
    this.chunks=[];
    this.doc.on("data",d=>this.chunks.push(d));
    this.W=this.doc.page.width-112;
  }
  getBuffer(){return new Promise(res=>{this.doc.on("end",()=>res(Buffer.concat(this.chunks)));this.doc.end();});}
  hdr(title){const d=this.doc,y=d.y;d.save();d.moveTo(56,40).lineTo(56+this.W,40).strokeColor(GOLD).lineWidth(1.5).stroke();d.fillColor(NAVY).font("Helvetica-Bold").fontSize(7).text("ARD CITY",56,26);d.fillColor(SLATE).font("Helvetica").fontSize(7).text(`  ·  ${safe(title)}  ·  CONFIDENTIAL`,56+d.widthOfString("ARD CITY",{fontSize:7}),26);d.restore();d.y=y;}
  rule(w=1.5,c=GOLD){const d=this.doc;d.save();d.moveTo(56,d.y).lineTo(56+this.W,d.y).strokeColor(c).lineWidth(w).stroke();d.y+=8;d.restore();return this;}
  thinRule(){return this.rule(0.5,"#CCCCCC");}
  h1(t,c=NAVY){this.doc.moveDown(1.1);this.doc.fillColor(c).font("Times-Bold").fontSize(19).text(safe(t));this.rule();return this;}
  h2(t,c=MIDBLUE){this.doc.moveDown(0.7);this.doc.fillColor(c).font("Helvetica-Bold").fontSize(12).text(safe(t));this.doc.moveDown(0.2);return this;}
  h3(t,c=STEEL){this.doc.moveDown(0.4);this.doc.fillColor(c).font("Helvetica-Bold").fontSize(9).text(safe(t).toUpperCase(),{characterSpacing:0.7});this.doc.moveDown(0.15);return this;}
  body(txt,indent=0){if(!txt?.trim())return this;const d=this.doc;txt.trim().split("\n").filter(l=>l.trim()).forEach(l=>{d.fillColor(DGRAY).font("Times-Roman").fontSize(10).text(safe(l.trim()),56+indent,d.y,{width:this.W-indent});d.moveDown(0.18);});return this;}
  lbl(label,value,color=STEEL){if(!value?.trim())return this;const d=this.doc;d.moveDown(0.35);d.fillColor(color).font("Helvetica-Bold").fontSize(10).text(`\u25b8  ${safe(label)}`);d.moveDown(0.08);this.body(value,14);return this;}
  infoTable(rows){const filtered=rows.filter(([,v])=>v?.trim?.());if(!filtered.length)return this;const d=this.doc,c1=148,c2=this.W-c1,rh=17;d.moveDown(0.4);filtered.forEach(([l,v],i)=>{const y=d.y;d.save();d.rect(56,y-2,c1,rh).fill(i%2===0?LGRAY:"#F7F9FC");d.rect(56+c1,y-2,c2,rh).fill(WHITE);d.restore();d.fillColor(MIDBLUE).font("Helvetica-Bold").fontSize(9).text(safe(l),62,y,{width:c1-10});d.fillColor(DGRAY).font("Times-Roman").fontSize(9).text(safe(v),56+c1+6,y,{width:c2-12});d.y=y+rh;});d.moveDown(0.35);return this;}
  kpiTable(kpis,hc=NAVY){if(!kpis?.length)return this;const d=this.doc,cols=[155,75,58,75,75,88],hdrs=["KPI","Target","Unit","Freq","Vertical","Owner"],rh=15;d.moveDown(0.35);let x=56;const hy=d.y;hdrs.forEach((h,i)=>{d.save().rect(x,hy-2,cols[i],rh).fill(hc).restore();d.fillColor(WHITE).font("Helvetica-Bold").fontSize(7.5).text(safe(h),x+3,hy,{width:cols[i]-6});x+=cols[i];});d.y=hy+rh;kpis.forEach((k,ri)=>{const y=d.y;const bg=ri%2===0?"#FAFAFA":LGRAY;x=56;[k.label,k.target,k.unit,k.freq,k.vertical==="all"?"All":(k.vertical||"—"),k.role||"—"].forEach((v,i)=>{d.save().rect(x,y-2,cols[i],rh).fill(bg).restore();d.fillColor(DGRAY).font(i===0?"Helvetica-Bold":"Times-Roman").fontSize(7.5).text(safe(v),x+3,y,{width:cols[i]-6});x+=cols[i];});d.y=y+rh;});d.moveDown(0.5);return this;}
  vertBanner(vert){const d=this.doc;d.addPage();const y=d.y;d.save().rect(56,y,this.W,26).fill(vert.color||"#1A4A7A").restore();d.fillColor(WHITE).font("Times-Bold").fontSize(15).text(`  ${safe(vert.label)}  \u00b7  ${safe(vert.fullName||vert.label)}`,64,y+6,{width:this.W-8});d.y=y+26;d.save().rect(56,d.y,this.W,14).fill(GOLD2).restore();d.fillColor(NAVY).font("Helvetica-Bold").fontSize(8).text("  ARD CITY  \u00b7  SALES VERTICAL PLAN",64,d.y+3,{characterSpacing:0.7});d.y+=14;d.moveDown(0.35);return this;}
  jdBanner(role){const d=this.doc;d.addPage();const y=d.y;d.save().rect(56,y,this.W,24).fill(role.color||"#1A4A7A").restore();d.fillColor(WHITE).font("Times-Bold").fontSize(13).text(`  ${safe(role.title)}  \u00b7  ${safe(role.band||"Manager")}`,64,y+5,{width:this.W-8});d.y=y+24;d.save().rect(56,d.y,this.W,13).fill(LGRAY).restore();d.fillColor(NAVY).font("Helvetica-Bold").fontSize(8).text("  ARD CITY  \u00b7  JOB DESCRIPTION",64,d.y+2,{characterSpacing:0.7});d.y+=13;d.moveDown(0.35);return this;}
}

export async function generatePdf(payload){
  const{formData={},sections=[],verticals=[],vertFields=[],kpiCats=[],roles=[],goalStatus={},goalNotes={},summary=""}=payload;
  const b=new PDFBuilder(),d=b.doc;
  const metaSec=sections.find(s=>s.id==="meta")||sections[0];
  const planTitle=(()=>{if(!metaSec)return"Master Sales Plan";const f=metaSec.fields.find(f=>f.label==="Plan Title"||f.id==="planTitle");return f?(formData[metaSec.id]?.[f.id]||"Master Sales Plan"):"Master Sales Plan";})();
  d.on("pageAdded",()=>b.hdr(planTitle));
  // COVER
  d.save().rect(0,0,d.page.width,10).fill(NAVY).restore();
  d.save().rect(0,10,d.page.width,5).fill(GOLD).restore();
  d.moveDown(2.8);
  d.fillColor(NAVY).font("Times-Bold").fontSize(38).text("ARD CITY",{align:"center",characterSpacing:5});
  d.moveDown(0.25);
  d.fillColor(GOLD).font("Times-Roman").fontSize(16).text(safe(planTitle),{align:"center"});
  d.moveDown(0.2);
  d.fillColor(SLATE).font("Helvetica").fontSize(8).text("SALES PLAN  \u00b7  KPI FRAMEWORK  \u00b7  SMART GOALS  \u00b7  JOB DESCRIPTIONS",{align:"center",characterSpacing:1});
  d.moveDown(0.5);b.rule();b.rule(0.5);d.moveDown(0.4);
  if(metaSec){const rows=metaSec.fields.slice(0,10).map(f=>[f.label,formData[metaSec.id]?.[f.id]||""]);rows.push(["Sales Verticals",verticals.map(v=>v.label).join(" \u00b7 ")]);b.infoTable(rows);}
  d.moveDown(0.4);d.fillColor(SLATE).font("Helvetica").fontSize(7).text("CONFIDENTIAL  \u00b7  FOR AUTHORIZED USE ONLY",{align:"center",characterSpacing:1});
  // EXEC SUMMARY
  d.addPage();b.hdr(planTitle);b.h1("Executive Summary");
  if(summary){d.fillColor(GOLD).font("Helvetica-Oblique").fontSize(9).text("AI Strategic Brief");d.moveDown(0.2);b.body(summary);b.thinRule();}
  // CORE SECTIONS
  for(const sec of sections){const sd=formData[sec.id]||{};if(!sec.fields.some(f=>sd[f.id]?.trim?.()))continue;d.addPage();b.hdr(planTitle);b.h1(sec.label);for(const f of sec.fields){const v=sd[f.id];if(v?.trim?.())b.lbl(f.label,v,sec.color||STEEL);}}
  // VERTICALS
  for(const vert of verticals){const vd=formData[vert.id]||{};if(!vertFields.some(f=>vd[f.id]?.trim?.()))continue;b.vertBanner(vert);b.hdr(planTitle);b.infoTable([["Vertical",`${vert.label} \u00b7 ${vert.fullName||vert.label}`],...vertFields.slice(0,3).map(f=>[f.label,vd[f.id]||""])]);for(const f of vertFields){const v=vd[f.id];if(v?.trim?.())b.lbl(f.label,v,vert.color||STEEL);}}
  // KPIS
  if(kpiCats?.some(c=>c.kpis?.length>0)){d.addPage();b.hdr(planTitle);b.h1("KPI Framework");b.body("KPIs linked to each vertical and role. Track actuals weekly, review monthly.");d.moveDown(0.4);for(const cat of kpiCats){if(!cat.kpis?.length)continue;b.h2(`${cat.icon||""} ${cat.label}`,cat.color||MIDBLUE);b.kpiTable(cat.kpis,cat.color||NAVY);}}
  // SMART GOALS
  const rwg=roles.filter(r=>r.goals?.length>0);
  if(rwg.length){d.addPage();b.hdr(planTitle);b.h1("SMART Goals by Role");b.body("Each goal is Specific, Measurable, Achievable, Relevant, Time-bound.");d.moveDown(0.4);for(const role of rwg){d.fillColor(role.color||MIDBLUE).font("Times-Bold").fontSize(12).text(safe(role.title));d.fillColor(SLATE).font("Helvetica").fontSize(8).text(safe(`${role.band} \u00b7 ${role.vertical==="all"?"All Verticals":role.vertical}`));b.rule(0.5,role.color||MIDBLUE);role.goals.forEach((g,i)=>{const sk=`${role.id}_${i}`,st=goalStatus[sk]||"pending",nt=goalNotes[sk]||"";d.moveDown(0.25);d.fillColor(role.color||MIDBLUE).font("Helvetica-Bold").fontSize(10).text(`Goal ${i+1}  [${safe(g.category||"General")}]  ${st.replace("_"," ").toUpperCase()}`);b.body(g.goal||"",10);d.fillColor(SLATE).font("Times-Italic").fontSize(9).text(`Timeframe: ${safe(g.timeframe||"TBD")}`,56+10);if(g.linked_kpis?.length)d.fillColor("#2A80D0").font("Helvetica").fontSize(9).text(`KPIs: ${g.linked_kpis.join(" \u00b7 ")}`,56+10);if(nt)d.fillColor(SLATE).font("Times-Italic").fontSize(9).text(`Progress: ${safe(nt)}`,56+10);});d.moveDown(0.5);b.thinRule();}}
  // JDs
  const rwj=roles.filter(r=>r.summary||r.responsibilities?.length>0);
  if(rwj.length){for(const role of rwj){b.jdBanner(role);b.hdr(planTitle);b.infoTable([["Band/Level",role.band||""],["Vertical",role.vertical==="all"?"All Verticals":(role.vertical||"")]]);if(role.summary){d.moveDown(0.25);d.save().moveTo(64,d.y).lineTo(64,d.y+28).strokeColor(role.color||MIDBLUE).lineWidth(2).stroke().restore();d.fillColor(SLATE).font("Times-Italic").fontSize(10).text(safe(role.summary),74,d.y,{width:b.W-18});d.moveDown(0.35);}if(role.responsibilities?.length){b.h3("Key Responsibilities",role.color||MIDBLUE);role.responsibilities.forEach((r,i)=>{d.fillColor(DGRAY).font("Times-Roman").fontSize(10).text(`${i+1}.  ${safe(r)}`,56+12);d.moveDown(0.18);});}if(role.requirements?.length){b.h3("Requirements",role.color||MIDBLUE);role.requirements.forEach(r=>{d.fillColor(DGRAY).font("Times-Roman").fontSize(10).text(`\u2022  ${safe(r)}`,56+12);d.moveDown(0.18);});}if(role.kpis?.length){b.h3("Linked KPIs",role.color||MIDBLUE);d.fillColor("#2A80D0").font("Helvetica").fontSize(9).text(role.kpis.join("  \u00b7  "),56+12);d.moveDown(0.4);}}}
  // Page numbers
  const pc=d.bufferedPageRange().count;
  for(let i=0;i<pc;i++){d.switchToPage(i);d.fillColor(GOLD).font("Helvetica-Bold").fontSize(7).text("ARD CITY  \u00b7  Sales Intelligence",56,d.page.height-22,{width:b.W,align:"left"});d.fillColor(SLATE).font("Helvetica").fontSize(7).text(`Page ${i+1} of ${pc}`,56,d.page.height-22,{width:b.W,align:"right"});}
  return b.getBuffer();
}
