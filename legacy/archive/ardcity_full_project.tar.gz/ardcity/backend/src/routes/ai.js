import { Router } from "express";

const router = Router();
const ANTHROPIC_API = "https://api.anthropic.com/v1/messages";

// POST /api/ai/review  — Full plan AI review
router.post("/review", async (req, res) => {
  const { planText, context = "full" } = req.body;
  if (!planText) return res.status(400).json({ error: "planText required" });

  const apiKey = req.headers["x-api-key"] || process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(400).json({ error: "Anthropic API key required. Set ANTHROPIC_API_KEY or pass x-api-key header." });

  try {
    const resp = await fetch(ANTHROPIC_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1200,
        system: `You are a senior Pakistan real estate sales strategist with deep expertise in ARD City-style township projects. 
Analyze the provided ARD City Sales Plan and produce an Executive Intelligence Brief with exactly 3 labeled sections:

STRENGTHS: What is well-planned, specific and credible
GAPS: What is missing, weak, or underspecified  
TOP 3 RECOMMENDATIONS: Numbered, specific, actionable priorities for the Pakistan market

Be direct, expert, and Pakistan-real-estate-specific. Reference NAPHDA, LDA, Zameen.com, NRP dynamics, and PKR economics where relevant.`,
        messages: [{ role: "user", content: `Review this ARD City Sales Plan (context: ${context}):\n\n${planText}` }],
      }),
    });

    if (!resp.ok) {
      const err = await resp.text();
      return res.status(resp.status).json({ error: `Anthropic API error: ${err}` });
    }

    const data = await resp.json();
    const text = data.content?.map(b => b.text).join("") || "";
    res.json({ result: text });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/ai/summary  — Generate executive summary
router.post("/summary", async (req, res) => {
  const { planMeta } = req.body;
  if (!planMeta) return res.status(400).json({ error: "planMeta required" });

  const apiKey = req.headers["x-api-key"] || process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return res.status(400).json({ error: "API key required" });

  try {
    const resp = await fetch(ANTHROPIC_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 400,
        system: `Respond ONLY with a valid JSON object: {"summary": "...130-word professional executive summary..."}. No markdown, no extra text, no explanation.`,
        messages: [{ role: "user", content: `Generate executive summary for: ${JSON.stringify(planMeta)}` }],
      }),
    });

    const data = await resp.json();
    const raw = data.content?.map(b => b.text).join("") || "{}";
    let parsed = {};
    try { parsed = JSON.parse(raw.replace(/```json|```/g, "").trim()); } catch {}
    res.json({ summary: parsed.summary || "" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export const aiRoute = router;
