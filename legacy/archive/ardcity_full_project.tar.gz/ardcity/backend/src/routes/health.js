import { Router } from "express";
const router = Router();

router.get("/", (req, res) => {
  res.json({
    status: "ok",
    service: "ARD City Sales Intelligence API",
    version: "1.0.0",
    timestamp: new Date().toISOString(),
    uptime: Math.floor(process.uptime()) + "s",
    env: process.env.NODE_ENV || "development",
  });
});

export const healthRoute = router;
