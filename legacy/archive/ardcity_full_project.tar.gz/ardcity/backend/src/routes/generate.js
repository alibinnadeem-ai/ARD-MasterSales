import { Router } from "express";
import { generateDocx } from "../generators/docxGenerator.js";
import { generatePdf } from "../generators/pdfGenerator.js";

const router = Router();

// POST /api/generate?type=docx|pdf
router.post("/", async (req, res) => {
  const type = (req.query.type || "docx").toLowerCase();
  if (!["docx", "pdf"].includes(type)) {
    return res.status(400).json({ error: "type must be docx or pdf" });
  }

  const payload = req.body;
  if (!payload) return res.status(400).json({ error: "Request body required" });

  try {
    if (type === "docx") {
      const buffer = await generateDocx(payload);
      const filename = `ARD_City_Sales_Intelligence_${Date.now()}.docx`;
      res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.setHeader("Content-Length", buffer.length);
      res.send(buffer);
    } else {
      const buffer = await generatePdf(payload);
      const filename = `ARD_City_Sales_Intelligence_${Date.now()}.pdf`;
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
      res.setHeader("Content-Length", buffer.length);
      res.send(buffer);
    }
  } catch (err) {
    console.error(`[GENERATE/${type.toUpperCase()}] Error:`, err.message);
    res.status(500).json({ error: `Document generation failed: ${err.message}` });
  }
});

export const generateRoute = router;
