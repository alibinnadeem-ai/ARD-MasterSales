import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { generateRoute } from "./routes/generate.js";
import { aiRoute } from "./routes/ai.js";
import { healthRoute } from "./routes/health.js";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 4000;

// ── MIDDLEWARE ────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.FRONTEND_URL || ["http://localhost:3000", "http://localhost:5173"],
  credentials: true,
}));

app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// Request logger (simple)
app.use((req, res, next) => {
  const ts = new Date().toISOString().slice(11, 23);
  console.log(`[${ts}] ${req.method} ${req.path}`);
  next();
});

// ── API ROUTES ────────────────────────────────────────────────────────
app.use("/api/generate", generateRoute);
app.use("/api/ai",       aiRoute);
app.use("/api/health",   healthRoute);

// ── STATIC FRONTEND (production) ─────────────────────────────────────
const publicDir = path.join(__dirname, "../../frontend/dist");
app.use(express.static(publicDir));
app.get("*", (req, res) => {
  res.sendFile(path.join(publicDir, "index.html"), (err) => {
    if (err) res.status(200).json({ status: "ARD City API running", version: "1.0.0" });
  });
});

// ── ERROR HANDLER ─────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error("[ERROR]", err.message);
  res.status(500).json({ error: err.message || "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════╗
║  ARD CITY SALES INTELLIGENCE               ║
║  Server running on http://localhost:${PORT}  ║
╚════════════════════════════════════════════╝
  `);
});

export default app;
