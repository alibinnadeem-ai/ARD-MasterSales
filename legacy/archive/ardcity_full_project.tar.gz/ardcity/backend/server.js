/**
 * ARD City Sales Intelligence System — Express Backend
 * Endpoints:
 *   POST /api/ard-generate?type=docx|pdf  — Document generation
 *   POST /api/save                          — Persist plan to disk/DB
 *   GET  /api/load/:id                      — Load saved plan
 *   GET  /api/plans                         — List all saved plans
 *   DELETE /api/plans/:id                   — Delete a plan
 *   POST /api/ai-review                     — Proxied AI review (server-side key)
 *   GET  /api/health                        — Health check
 */
require("dotenv").config();
const express  = require("express");
const cors     = require("cors");
const path     = require("path");
const fs       = require("fs");
const { v4: uuidv4 } = require("uuid");
const { execSync, spawn } = require("child_process");

const app  = express();
const PORT = process.env.PORT || 3001;
const DATA_DIR = path.join(__dirname, "data");
const TEMP_DIR = path.join(__dirname, "temp");

// Ensure directories exist
[DATA_DIR, TEMP_DIR].forEach(d => !fs.existsSync(d) && fs.mkdirSync(d, { recursive: true }));

// ── MIDDLEWARE ─────────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.FRONTEND_URL || "http://localhost:5173",
  credentials: true,
}));
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Serve React build in production
if (process.env.NODE_ENV === "production") {
  const buildPath = path.join(__dirname, "../frontend/dist");
  if (fs.existsSync(buildPath)) {
    app.use(express.static(buildPath));
    app.get("/", (req, res) => res.sendFile(path.join(buildPath, "index.html")));
  }
}

// ── HEALTH CHECK ───────────────────────────────────────────────────────────
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    version: "1.0.0",
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || "development",
  });
});

// ── DOCUMENT GENERATION ────────────────────────────────────────────────────
app.post("/api/ard-generate", async (req, res) => {
  const type = req.query.type || "docx";
  const payload = req.body;
  const jobId = uuidv4();
  const outPath = path.join(TEMP_DIR, `ard_${jobId}.${type}`);

  try {
    // Add AI-generated summary if Anthropic key is set and summary not provided
    if (!payload.summary && process.env.ANTHROPIC_API_KEY) {
      try {
        const fetch = (await import("node-fetch")).default;
        const metaText = JSON.stringify(payload.formData?.meta || {}).slice(0, 2000);
        const resp = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": process.env.ANTHROPIC_API_KEY,
            "anthropic-version": "2023-06-01",
          },
          body: JSON.stringify({
            model: "claude-sonnet-4-20250514",
            max_tokens: 500,
            system: 'Respond ONLY with JSON: {"summary":"...120-word executive summary..."}',
            messages: [{ role: "user", content: `ARD City plan: ${metaText}` }],
          }),
        });
        const d = await resp.json();
        const txt = d.content?.map(b => b.text).join("") || "{}";
        payload.summary = JSON.parse(txt.replace(/```json|```/g, "").trim()).summary || "";
      } catch (_) { /* summary optional */ }
    }

    payload.output_path = outPath;

    if (type === "docx") {
      await generateDocx(payload, outPath);
    } else if (type === "pdf") {
      await generatePdf(payload, outPath);
    } else {
      return res.status(400).json({ error: "type must be docx or pdf" });
    }

    if (!fs.existsSync(outPath)) {
      return res.status(500).json({ error: "Document generation failed — output not found" });
    }

    const mimeTypes = { docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", pdf: "application/pdf" };
    const filename = `ARD_City_Sales_Intelligence_${new Date().toISOString().slice(0,10)}.${type}`;
    res.setHeader("Content-Type", mimeTypes[type]);
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    res.setHeader("Content-Length", fs.statSync(outPath).size);

    const stream = fs.createReadStream(outPath);
    stream.pipe(res);
    stream.on("end", () => {
      try { fs.unlinkSync(outPath); } catch (_) {}
    });

  } catch (err) {
    console.error("Generation error:", err);
    res.status(500).json({ error: err.message });
  }
});

// ── SAVE PLAN ──────────────────────────────────────────────────────────────
app.post("/api/save", (req, res) => {
  try {
    const { id, name, ...planData } = req.body;
    const planId = id || uuidv4();
    const planName = name || planData.formData?.meta?.planTitle || `Plan ${new Date().toLocaleDateString()}`;
    const record = {
      id: planId,
      name: planName,
      savedAt: new Date().toISOString(),
      ...planData,
    };
    fs.writeFileSync(path.join(DATA_DIR, `${planId}.json`), JSON.stringify(record, null, 2));
    res.json({ success: true, id: planId, name: planName, savedAt: record.savedAt });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── LOAD PLAN ──────────────────────────────────────────────────────────────
app.get("/api/load/:id", (req, res) => {
  try {
    const file = path.join(DATA_DIR, `${req.params.id}.json`);
    if (!fs.existsSync(file)) return res.status(404).json({ error: "Plan not found" });
    res.json(JSON.parse(fs.readFileSync(file, "utf8")));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── LIST PLANS ─────────────────────────────────────────────────────────────
app.get("/api/plans", (req, res) => {
  try {
    const plans = fs.readdirSync(DATA_DIR)
      .filter(f => f.endsWith(".json"))
      .map(f => {
        try {
          const d = JSON.parse(fs.readFileSync(path.join(DATA_DIR, f), "utf8"));
          return { id: d.id, name: d.name, savedAt: d.savedAt };
        } catch (_) { return null; }
      })
      .filter(Boolean)
      .sort((a, b) => new Date(b.savedAt) - new Date(a.savedAt));
    res.json(plans);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DELETE PLAN ────────────────────────────────────────────────────────────
app.delete("/api/plans/:id", (req, res) => {
  try {
    const file = path.join(DATA_DIR, `${req.params.id}.json`);
    if (fs.existsSync(file)) fs.unlinkSync(file);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── AI REVIEW PROXY (uses server-side API key) ─────────────────────────────
app.post("/api/ai-review", async (req, res) => {
  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(400).json({ error: "ANTHROPIC_API_KEY not configured on server" });
  }
  try {
    const fetch = (await import("node-fetch")).default;
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: "You are a senior Pakistan real estate sales strategist. Analyze the provided ARD City Sales Plan and produce an Executive Intelligence Brief in 3 labeled sections: STRENGTHS, GAPS, TOP 3 RECOMMENDATIONS. Be direct, expert, and Pakistan-market-specific.",
        messages: req.body.messages || [{ role: "user", content: req.body.content || "" }],
      }),
    });
    const data = await response.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── DOCX GENERATOR (inline, no child process) ─────────────────────────────
async function generateDocx(payload, outPath) {
  const {
    Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
    AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType, Header, Footer,
  } = require("docx");

  const fd = payload.formData || {};
  const sections = payload.sections || [];
  const verticals = payload.verticals || [];
  const vertFields = payload.vertFields || [];
  const kpiCats = payload.kpiCats || [];
  const roles = payload.roles || [];
  const goalStatus = payload.goalStatus || {};
  const goalNotes = payload.goalNotes || {};
  const summary = payload.summary || "";
  const meta = fd.meta || {};

  const GOLD = "B8912A"; const NAVY = "0D1F3C"; const STEEL = "2C5282"; const SLATE = "4A5568";

  const sp = (b=0,a=0) => ({ spacing: { before:b, after:a } });
  const bdr = (c="CCCCCC") => ({ style:BorderStyle.SINGLE, size:1, color:c });
  const bdrAll = (c="CCCCCC") => ({ top:bdr(c), bottom:bdr(c), left:bdr(c), right:bdr(c) });

  function goldRule() { return new Paragraph({ ...sp(140,80), border:{ bottom:{ style:BorderStyle.SINGLE, size:5, color:GOLD, space:4 }}, children:[] }); }
  function thinRule() { return new Paragraph({ ...sp(80,80), border:{ bottom:{ style:BorderStyle.SINGLE, size:1, color:"DDDDDD", space:2 }}, children:[] }); }
  function pgBreak() { return new Paragraph({ pageBreakBefore:true, children:[] }); }

  function H1(text, color=NAVY) {
    return new Paragraph({ heading:HeadingLevel.HEADING_1, ...sp(360,120),
      children:[new TextRun({ text, bold:true, size:30, color, font:"Garamond" })] });
  }
  function H2(text, color=STEEL) {
    return new Paragraph({ heading:HeadingLevel.HEADING_2, ...sp(220,80),
      children:[new TextRun({ text, bold:true, size:24, color, font:"Garamond" })] });
  }
  function labelBlk(label, value, color=STEEL) {
    if (!value?.trim()) return [];
    return [
      new Paragraph({ ...sp(140,40), children:[new TextRun({ text:`▸  ${label}`, bold:true, size:20, color, font:"Arial" })] }),
      ...value.trim().split("\n").filter(l=>l.trim()).map(line =>
        new Paragraph({ ...sp(30,40), indent:{left:320}, children:[new TextRun({ text:line.trim(), size:20, font:"Garamond", color:"2D2D2D" })] })
      ),
    ];
  }
  function infoTable(rows, colW=[2600,6400]) {
    const filtered = rows.filter(r=>r[1]?.trim?.());
    if (!filtered.length) return [];
    const b = bdrAll("DDDDDD");
    return [new Table({
      width:{size:9000,type:WidthType.DXA}, columnWidths:colW,
      rows: filtered.map(([lbl,val],i) => new TableRow({ children:[
        new TableCell({ borders:b, width:{size:colW[0],type:WidthType.DXA},
          shading:{ fill:i%2===0?"EEF2F8":"F5F7FC", type:ShadingType.CLEAR },
          margins:{top:70,bottom:70,left:120,right:80},
          children:[new Paragraph({ children:[new TextRun({ text:lbl, bold:true, size:18, font:"Arial", color:STEEL })] })] }),
        new TableCell({ borders:b, width:{size:colW[1],type:WidthType.DXA},
          margins:{top:70,bottom:70,left:120,right:80},
          children:[new Paragraph({ children:[new TextRun({ text:val||"—", size:19, font:"Garamond", color:"2D2D2D" })] })] }),
      ]})),
    }), new Paragraph({...sp(100,0)})];
  }
  function vertBanner(v) {
    return [
      pgBreak(),
      new Paragraph({ ...sp(0,0), shading:{fill:v.color?.replace("#","")||NAVY, type:ShadingType.CLEAR},
        children:[new TextRun({ text:`  ${v.label||"Vertical"}  ·  ${v.fullName||""}`, bold:true, size:26, color:"FFFFFF", font:"Garamond" })] }),
      new Paragraph({ ...sp(0,120), shading:{fill:GOLD, type:ShadingType.CLEAR},
        children:[new TextRun({ text:"  ARD CITY  ·  SALES VERTICAL PLAN", size:16, color:NAVY, font:"Arial", characterSpacing:80 })] }),
      thinRule(),
    ];
  }
  function kpiTable(kpis, hColor=NAVY) {
    const hdrs = ["KPI","Target","Unit","Frequency","Vertical"];
    const b = bdrAll("DDDDDD");
    const colWs = [2800,1200,800,1300,900];
    const hRow = new TableRow({ children: hdrs.map((h,i) => new TableCell({
      borders:b, shading:{fill:hColor.replace("#",""),type:ShadingType.CLEAR},
      width:{size:colWs[i],type:WidthType.DXA}, margins:{top:60,bottom:60,left:80,right:60},
      children:[new Paragraph({ children:[new TextRun({ text:h, bold:true, size:17, color:"FFFFFF", font:"Arial" })] })],
    }))});
    const rows = kpis.map((k,ri) => new TableRow({ children:
      [k.label||"",k.target||"—",k.unit||"",k.freq||"",k.vertical==="all"?"All":k.vertical||""]
      .map((v,i) => new TableCell({
        borders:b, width:{size:colWs[i],type:WidthType.DXA},
        shading:{fill:ri%2===0?"FAFAFA":"EEF2F8",type:ShadingType.CLEAR},
        margins:{top:60,bottom:60,left:80,right:60},
        children:[new Paragraph({ children:[new TextRun({ text:String(v), size:18, font:i===0?"Arial":"Garamond", color:"2D2D2D" })] })],
      }))
    }));
    return new Table({ width:{size:9000,type:WidthType.DXA}, columnWidths:colWs, rows:[hRow,...rows] });
  }

  const children = [];

  // COVER
  const metaTitle = (()=>{const s=sections.find(s=>s.id==="meta");return s?.fields?.find(f=>f.label==="Plan Title")?fd.meta?.[s.fields.find(f=>f.label==="Plan Title").id]||"MASTER SALES PLAN":"MASTER SALES PLAN"})();
  const metaDev   = (()=>{const s=sections.find(s=>s.id==="meta");return s?.fields?.find(f=>f.label.includes("Development"))?fd.meta?.[s.fields.find(f=>f.label.includes("Development")).id]||"ARD City":"ARD City"})();
  const prepBy    = (()=>{const s=sections.find(s=>s.id==="meta");return s?.fields?.find(f=>f.label.includes("Prepared"))?fd.meta?.[s.fields.find(f=>f.label.includes("Prepared")).id]||"":""})()||meta.preparedBy||"";
  const planDate  = meta.date||"";

  children.push(
    new Paragraph({ ...sp(0,0), shading:{fill:NAVY,type:ShadingType.CLEAR}, children:[new TextRun({text:"  ",size:8})] }),
    new Paragraph({ ...sp(0,0), shading:{fill:GOLD,type:ShadingType.CLEAR}, children:[new TextRun({text:"  ",size:14})] }),
    new Paragraph({ ...sp(900,0), alignment:AlignmentType.CENTER,
      children:[new TextRun({text:metaDev.toUpperCase(),bold:true,size:64,color:NAVY,font:"Garamond",characterSpacing:180})] }),
    new Paragraph({ ...sp(60,0), alignment:AlignmentType.CENTER,
      children:[new TextRun({text:metaTitle,size:28,color:GOLD,font:"Garamond"})] }),
    new Paragraph({ ...sp(20,0), alignment:AlignmentType.CENTER,
      children:[new TextRun({text:"SALES PLAN  ·  KPI FRAMEWORK  ·  SMART GOALS  ·  JOB DESCRIPTIONS",size:14,color:SLATE,font:"Arial",characterSpacing:80})] }),
    new Paragraph({ ...sp(180,160), alignment:AlignmentType.CENTER,
      border:{top:{style:BorderStyle.SINGLE,size:4,color:GOLD,space:1},bottom:{style:BorderStyle.SINGLE,size:4,color:GOLD,space:1}},
      children:[new TextRun({text:"  CONFIDENTIAL  ·  STRATEGIC DOCUMENT  ",size:16,color:SLATE,font:"Arial"})] }),
  );
  children.push(...infoTable([
    ["Development", metaDev], ["Prepared By", prepBy], ["Date", planDate],
    ["Total Revenue Target", meta.totalRevenue||""], ["Total Inventory", meta.totalInventory||""],
    ["Launch Date", meta.launchDate||""], ["Plan Period", meta.planPeriod||""],
    ["Regulatory", meta.regulatory||""],
    ["Sales Verticals", verticals.map(v=>v.label).join(" · ")||"B2G · B2C · B2B · Channel · Diaspora"],
  ], [2400,6600]));

  // EXECUTIVE SUMMARY
  children.push(pgBreak(), H1("Executive Summary"), goldRule());
  if (summary) {
    children.push(new Paragraph({...sp(80,60), children:[new TextRun({text:"AI Strategic Intelligence Brief",italics:true,size:19,color:GOLD,font:"Arial"})]}));
    summary.trim().split("\n").forEach(l => { if(l.trim()) children.push(new Paragraph({...sp(30,50),indent:{left:240},children:[new TextRun({text:l.trim(),size:20,font:"Garamond",color:"2D2D2D"})]})); });
    children.push(thinRule());
  }

  // DYNAMIC CORE SECTIONS
  sections.forEach(sec => {
    children.push(pgBreak(), H1(sec.label, "#"+NAVY), goldRule());
    (sec.fields||[]).forEach(f => {
      const val = fd[sec.id]?.[f.id];
      if (val?.trim()) children.push(...labelBlk(f.label, val));
    });
  });

  // DYNAMIC VERTICALS
  verticals.forEach(v => {
    const vData = fd[v.id] || {};
    const hasContent = vertFields.some(f => vData[f.id]?.trim());
    if (!hasContent) return;
    children.push(...vertBanner(v));
    children.push(...infoTable([
      ["Vertical", `${v.label} — ${v.fullName}`],
      ...vertFields.slice(0,4).map(f=>[f.label, vData[f.id]||""]),
    ]));
    vertFields.slice(4).forEach(f => { if (vData[f.id]?.trim()) children.push(...labelBlk(f.label, vData[f.id], "#"+(v.color?.replace("#","")||STEEL))); });
  });

  // KPI FRAMEWORK
  children.push(pgBreak(), H1("KPI Framework", "#"+NAVY), goldRule());
  children.push(new Paragraph({...sp(60,120),children:[new TextRun({text:"Key Performance Indicators linked to each vertical, role, and SMART goal.",size:20,font:"Garamond",color:"2D2D2D"})]}));
  kpiCats.forEach(cat => {
    if (!cat.kpis?.length) return;
    children.push(H2(`${cat.icon||""} ${cat.label}`, "#"+(cat.color?.replace("#","")||STEEL)));
    children.push(kpiTable(cat.kpis, cat.color?.replace("#","")||NAVY));
    children.push(new Paragraph({...sp(100,0)}));
  });

  // SMART GOALS
  children.push(pgBreak(), H1("SMART Goals by Role", "#"+NAVY), goldRule());
  roles.forEach(role => {
    const goals = role.goals || [];
    if (!goals.length) return;
    const rc = role.color?.replace("#","")||NAVY;
    children.push(new Paragraph({...sp(240,60),
      children:[new TextRun({text:role.title, bold:true, size:22, color:"#"+rc, font:"Garamond"}),
        new TextRun({text:`  [${role.band||""}]`, size:18, color:SLATE, font:"Arial"})]}));
    children.push(new Paragraph({...sp(0,80), border:{bottom:{style:BorderStyle.SINGLE,size:2,color:rc,space:2}},children:[]}));
    goals.forEach((g,i) => {
      const key = `${role.id}_${i}`;
      const status = goalStatus[key] || "pending";
      const note = goalNotes[key] || "";
      const statusColors = {pending:"888888",in_progress:"2A80D0",achieved:"3DA863",at_risk:"C44030"};
      children.push(
        new Paragraph({...sp(120,30), children:[
          new TextRun({text:`Goal ${i+1}  `, bold:true, size:20, color:"#"+rc, font:"Arial"}),
          new TextRun({text:`[${g.category||"General"}]  `, size:17, color:"888888", font:"Arial"}),
          new TextRun({text:status.replace("_"," ").toUpperCase(), size:16, color:statusColors[status]||"888888", font:"Arial"}),
        ]}),
      );
      if (g.goal?.trim()) {
        g.goal.split("\n").forEach(l => { if(l.trim()) children.push(new Paragraph({...sp(30,30),indent:{left:320},children:[new TextRun({text:l.trim(),size:20,font:"Garamond",color:"2D2D2D"})]})); });
      }
      children.push(new Paragraph({...sp(20,30),indent:{left:320},children:[new TextRun({text:`Timeframe: ${g.timeframe||"TBD"}`,italics:true,size:18,color:SLATE,font:"Arial"})]}));
      if (g.linked_kpis?.length) {
        children.push(new Paragraph({...sp(20,60),indent:{left:320},children:[new TextRun({text:`KPIs: ${g.linked_kpis.join(" · ")}`,size:17,color:"2A80D0",font:"Arial"})]}));
      }
      if (note?.trim()) {
        children.push(new Paragraph({...sp(20,60),indent:{left:320},children:[new TextRun({text:`Note: ${note.trim()}`,italics:true,size:17,color:"888888",font:"Arial"})]}));
      }
    });
    children.push(thinRule());
  });

  // JOB DESCRIPTIONS
  children.push(pgBreak(), H1("Job Descriptions", "#"+NAVY), goldRule());
  roles.forEach(role => {
    const rc = role.color?.replace("#","")||NAVY;
    children.push(
      pgBreak(),
      new Paragraph({...sp(0,0), shading:{fill:rc,type:ShadingType.CLEAR},
        children:[new TextRun({text:`  ${role.title}  ·  ${role.band||""}`,bold:true,size:22,color:"FFFFFF",font:"Garamond"})]}),
      new Paragraph({...sp(0,140), shading:{fill:"EEF2F8",type:ShadingType.CLEAR},
        children:[new TextRun({text:`  ARD CITY  ·  JOB DESCRIPTION  ·  ${(role.vertical==="all"?"All Verticals":role.vertical||"").toUpperCase()}`,size:15,color:NAVY,font:"Arial",characterSpacing:60})]}),
    );
    if (role.summary?.trim()) {
      children.push(new Paragraph({...sp(120,80),indent:{left:180},
        border:{left:{style:BorderStyle.SINGLE,size:4,color:rc,space:8}},
        children:[new TextRun({text:role.summary.trim(),italics:true,size:19,color:SLATE,font:"Garamond"})]}));
    }
    if (role.responsibilities?.length) {
      children.push(new Paragraph({...sp(140,50),children:[new TextRun({text:"KEY RESPONSIBILITIES",bold:true,size:17,color:"#"+rc,font:"Arial",characterSpacing:40})]}));
      role.responsibilities.forEach((r,i) => {
        children.push(new Paragraph({...sp(30,40),indent:{left:300},
          children:[new TextRun({text:`${i+1}.  `,bold:true,size:19,color:"#"+rc,font:"Arial"}),new TextRun({text:r,size:19,font:"Garamond",color:"2D2D2D"})]}));
      });
    }
    if (role.requirements?.length) {
      children.push(new Paragraph({...sp(140,50),children:[new TextRun({text:"REQUIREMENTS",bold:true,size:17,color:"#"+rc,font:"Arial",characterSpacing:40})]}));
      role.requirements.forEach(r => {
        children.push(new Paragraph({...sp(30,40),indent:{left:300},
          children:[new TextRun({text:"•  ",size:19,color:"888888",font:"Arial"}),new TextRun({text:r,size:19,font:"Garamond",color:"444444"})]}));
      });
    }
    if (role.kpis?.length) {
      children.push(new Paragraph({...sp(140,50),children:[new TextRun({text:"LINKED KPIs",bold:true,size:17,color:"2A80D0",font:"Arial",characterSpacing:40})]}));
      children.push(new Paragraph({...sp(30,60),indent:{left:300},
        children:[new TextRun({text:role.kpis.join("  ·  "),size:18,color:"2A80D0",font:"Arial"})]}));
    }
  });

  // BUILD
  const doc = new Document({
    styles:{
      default:{ document:{ run:{ font:"Garamond", size:20 } } },
      paragraphStyles:[
        {id:"Heading1",name:"Heading 1",basedOn:"Normal",next:"Normal",quickFormat:true,
          run:{size:30,bold:true,font:"Garamond",color:NAVY},paragraph:{spacing:{before:360,after:120},outlineLevel:0}},
        {id:"Heading2",name:"Heading 2",basedOn:"Normal",next:"Normal",quickFormat:true,
          run:{size:24,bold:true,font:"Garamond",color:STEEL},paragraph:{spacing:{before:220,after:80},outlineLevel:1}},
      ],
    },
    sections:[{
      properties:{ page:{size:{width:12240,height:15840},margin:{top:1200,right:1200,bottom:1200,left:1200}} },
      headers:{ default: new Header({ children:[
        new Paragraph({ border:{bottom:{style:BorderStyle.SINGLE,size:4,color:GOLD,space:4}},
          children:[
            new TextRun({text:`${metaDev.toUpperCase()}  ·  `,bold:true,size:16,color:NAVY,font:"Arial",characterSpacing:60}),
            new TextRun({text:metaTitle,size:16,color:SLATE,font:"Arial"}),
            new TextRun({text:"    CONFIDENTIAL",size:14,color:"AAAAAA",font:"Arial"}),
          ]}),
      ]})},
      footers:{ default: new Footer({ children:[
        new Paragraph({ border:{top:{style:BorderStyle.SINGLE,size:2,color:"CCCCCC",space:4}},
          children:[
            new TextRun({text:prepBy,size:14,color:"888888",font:"Arial"}),
            new TextRun({text:`   ·   ${planDate}   ·   ARD City Sales Intelligence Package`,size:14,color:"AAAAAA",font:"Arial"}),
          ]}),
      ]})},
      children: children.filter(Boolean),
    }],
  });

  const buf = await Packer.toBuffer(doc);
  require("fs").writeFileSync(outPath, buf);
}

// ── PDF GENERATOR (calls Python) ───────────────────────────────────────────
function generatePdf(payload, outPath) {
  return new Promise((resolve, reject) => {
    const pyScript = require("path").join(__dirname, "generators", "pdf_generator.py");
    const input = JSON.stringify({ ...payload, output_path: outPath });
    const proc = spawn("python3", [pyScript], { stdio: ["pipe","pipe","pipe"] });
    proc.stdin.write(input);
    proc.stdin.end();
    let stdout = "", stderr = "";
    proc.stdout.on("data", d => stdout += d);
    proc.stderr.on("data", d => stderr += d);
    proc.on("close", code => {
      if (code !== 0) return reject(new Error(`PDF generation failed (code ${code}): ${stderr.slice(0,500)}`));
      try { const r = JSON.parse(stdout); if (r.success) resolve(r); else reject(new Error(r.error||"PDF failed")); }
      catch { reject(new Error(`PDF output parse error: ${stdout.slice(0,200)}`)); }
    });
  });
}

// ── START ──────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🏙  ARD City Sales Intelligence API`);
  console.log(`   Running on http://localhost:${PORT}`);
  console.log(`   Environment: ${process.env.NODE_ENV || "development"}`);
  console.log(`   Data directory: ${DATA_DIR}\n`);
});

module.exports = app;
