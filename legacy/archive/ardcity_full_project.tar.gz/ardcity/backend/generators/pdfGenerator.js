import { spawn } from "child_process";
import { fileURLToPath } from "url";
import path from "path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PYTHON_SCRIPT = path.join(__dirname, "../generators/pdf_generator.py");

export function generatePdf(payload) {
  return new Promise((resolve, reject) => {
    const python = spawn("python3", [PYTHON_SCRIPT], {
      env: { ...process.env, PYTHONUNBUFFERED: "1" },
    });

    const chunks = [];
    const errChunks = [];

    python.stdout.on("data", d => chunks.push(d));
    python.stderr.on("data", d => errChunks.push(d));

    python.on("close", code => {
      if (code !== 0) {
        const errMsg = Buffer.concat(errChunks).toString();
        return reject(new Error(`PDF generator failed (code ${code}): ${errMsg}`));
      }
      resolve(Buffer.concat(chunks));
    });

    python.on("error", err => reject(new Error(`Failed to start Python: ${err.message}`)));

    // Send payload as JSON via stdin
    python.stdin.write(JSON.stringify(payload));
    python.stdin.end();
  });
}
