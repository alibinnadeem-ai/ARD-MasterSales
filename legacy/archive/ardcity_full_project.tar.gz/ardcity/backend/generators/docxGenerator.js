import {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType,
  Header, Footer, PageBreak,
} from "docx";

// ── PALETTE ──────────────────────────────────────────────────────────
const GOLD   = "B8912A";
const NAVY   = "0D1F3C";
const STEEL  = "2C5282";
const SLATE  = "4A5568";
const DGRAY  = "2D2D2D";
const WHITE  = "FFFFFF";

// ── HELPERS ──────────────────────────────────────────────────────────
const sp = (b = 0, a = 0) => ({ spacing: { before: b, after: a } });
const bdr = (color = "DDDDDD") => ({
  style: BorderStyle.SINGLE, size: 1, color,
});
const borders = (c = "DDDDDD") => ({
  top: bdr(c), bottom: bdr(c), left: bdr(c), right: bdr(c),
});

function goldRule() {
  return new Paragraph({
    ...sp(160, 80),
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: GOLD, space: 4 } },
    children: [],
  });
}
function thinRule() {
  return new Paragraph({
    ...sp(80, 80),
    border: { bottom: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC", space: 2 } },
    children: [],
  });
}
function pageBreak() {
  return new Paragraph({ pageBreakBefore: true, children: [] });
}

function H1(text, color = NAVY) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    ...sp(400, 160),
    children: [new TextRun({ text, bold: true, size: 32, color, font: "Garamond" })],
  });
}
function H2(text, color = STEEL) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    ...sp(240, 100),
    children: [new TextRun({ text, bold: true, size: 24, color, font: "Garamond" })],
  });
}
function H3(text, color = SLATE) {
  return new Paragraph({
    ...sp(180, 60),
    children: [new TextRun({ text: text.toUpperCase(), bold: true, size: 17, color, font: "Arial", characterSpacing: 40 })],
  });
}

function bodyLines(text, indent = 0) {
  if (!text?.trim()) return [];
  return text.trim().split("\n").filter(l => l.trim()).map(line =>
    new Paragraph({
      ...sp(40, 50),
      indent: indent ? { left: indent } : undefined,
      children: [new TextRun({ text: line.trim(), size: 21, font: "Garamond", color: DGRAY })],
    })
  );
}

function labelBlock(label, value, color = STEEL) {
  if (!value?.trim()) return [];
  return [
    new Paragraph({
      ...sp(160, 50),
      children: [
        new TextRun({ text: "▸  ", size: 19, color, font: "Arial" }),
        new TextRun({ text: label, bold: true, size: 20, color, font: "Arial" }),
      ],
    }),
    ...bodyLines(value, 320),
  ];
}

function infoTable(rows, colW = [2800, 6200]) {
  const filtered = rows.filter(([, v]) => v?.toString?.().trim());
  if (!filtered.length) return [];
  const b = borders("DDDDDD");
  return [
    new Table({
      width: { size: 9000, type: WidthType.DXA },
      columnWidths: colW,
      rows: filtered.map(([lbl, val], i) =>
        new TableRow({
          children: [
            new TableCell({
              borders: b,
              width: { size: colW[0], type: WidthType.DXA },
              shading: { fill: i % 2 === 0 ? "EEF2F8" : "F5F7FB", type: ShadingType.CLEAR },
              margins: { top: 80, bottom: 80, left: 140, right: 100 },
              children: [new Paragraph({ children: [new TextRun({ text: String(lbl), bold: true, size: 19, font: "Arial", color: STEEL })] })],
            }),
            new TableCell({
              borders: b,
              width: { size: colW[1], type: WidthType.DXA },
              margins: { top: 80, bottom: 80, left: 140, right: 100 },
              children: [new Paragraph({ children: [new TextRun({ text: String(val || "—"), size: 20, font: "Garamond", color: DGRAY })] })],
            }),
          ],
        })
      ),
    }),
    new Paragraph({ ...sp(120, 0) }),
  ];
}

function kpiTable(kpis, headerColor = NAVY) {
  if (!kpis?.length) return [];
  const hdrs = ["KPI", "Target", "Unit", "Freq", "Vertical", "Role"];
  const colW = [2400, 1200, 800, 1000, 1200, 2000];
  const b = borders("DDDDDD");
  const headerRow = new TableRow({
    children: hdrs.map((h, i) =>
      new TableCell({
        borders: b,
        shading: { fill: headerColor, type: ShadingType.CLEAR },
        width: { size: colW[i], type: WidthType.DXA },
        margins: { top: 70, bottom: 70, left: 90, right: 70 },
        children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, size: 17, color: WHITE, font: "Arial" })] })],
      })
    ),
  });
  const dataRows = kpis.map((k, ri) =>
    new TableRow({
      children: [k.label, k.target, k.unit, k.freq, k.vertical === "all" ? "All" : k.vertical, k.role || "—"]
        .map((val, i) =>
          new TableCell({
            borders: b,
            width: { size: colW[i], type: WidthType.DXA },
            shading: { fill: ri % 2 === 0 ? "FAFAFA" : "F0F4F8", type: ShadingType.CLEAR },
            margins: { top: 65, bottom: 65, left: 90, right: 70 },
            children: [new Paragraph({ children: [new TextRun({ text: String(val || "—"), size: 18, font: i === 0 ? "Arial" : "Garamond", color: DGRAY })] })],
          })
        ),
    })
  );
  return [
    new Table({ width: { size: 8600, type: WidthType.DXA }, columnWidths: colW, rows: [headerRow, ...dataRows] }),
    new Paragraph({ ...sp(100, 0) }),
  ];
}

function vertBanner(vert) {
  const color = vert.color?.replace("#", "") || NAVY;
  return [
    pageBreak(),
    new Paragraph({
      ...sp(0, 0),
      shading: { fill: color, type: ShadingType.CLEAR },
      children: [new TextRun({ text: `  ${vert.icon || "◆"}  ${vert.label}  ·  ${vert.fullName}`, bold: true, size: 26, color: WHITE, font: "Garamond" })],
    }),
    new Paragraph({
      ...sp(0, 120),
      shading: { fill: GOLD, type: ShadingType.CLEAR },
      children: [new TextRun({ text: "  ARD CITY  ·  SALES VERTICAL PLAN", size: 16, color: NAVY, font: "Arial", characterSpacing: 80 })],
    }),
    thinRule(),
  ];
}

// ── MAIN GENERATOR ───────────────────────────────────────────────────
export async function generateDocx(payload) {
  const {
    formData = {},
    sections = [],
    verticals = [],
    vertFields = [],
    kpiCats = [],
    roles = [],
    goalStatus = {},
    goalNotes = {},
    summary = "",
  } = payload;

  const meta = formData.meta || {};
  const planTitle = (sections.find(s => s.id === "meta")?.fields?.find(f => f.label === "Plan Title") && formData.meta?.[(sections.find(s => s.id === "meta")?.fields?.find(f => f.label === "Plan Title"))?.id]) || "ARD City Master Sales Plan";
  const preparedBy = Object.values(meta).find((_, i) => Object.keys(meta)[i] && sections.find(s => s.id === "meta")?.fields?.find(f => f.id === Object.keys(meta)[i] && f.label === "Prepared By")) || "";

  const children = [];

  // ── COVER ─────────────────────────────────────────────────────────
  children.push(
    new Paragraph({ ...sp(0, 0), shading: { fill: NAVY, type: ShadingType.CLEAR }, children: [new TextRun({ text: " ", size: 4 })] }),
    new Paragraph({ ...sp(0, 0), shading: { fill: GOLD, type: ShadingType.CLEAR }, children: [new TextRun({ text: " ", size: 14 })] }),
    new Paragraph({
      ...sp(1000, 0), alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: "ARD CITY", bold: true, size: 72, color: NAVY, font: "Garamond", characterSpacing: 200 })],
    }),
    new Paragraph({
      ...sp(60, 60), alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: planTitle, size: 32, color: GOLD, font: "Garamond" })],
    }),
    new Paragraph({
      ...sp(20, 0), alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: "SALES PLAN  ·  KPI FRAMEWORK  ·  SMART GOALS  ·  JOB DESCRIPTIONS", size: 16, color: SLATE, font: "Arial", characterSpacing: 100 })],
    }),
    new Paragraph({
      ...sp(200, 200), alignment: AlignmentType.CENTER,
      border: {
        top: { style: BorderStyle.SINGLE, size: 4, color: GOLD, space: 1 },
        bottom: { style: BorderStyle.SINGLE, size: 4, color: GOLD, space: 1 },
      },
      children: [new TextRun({ text: "  CONFIDENTIAL  ·  STRATEGIC DOCUMENT  ", size: 17, color: SLATE, font: "Arial" })],
    }),
  );

  // Cover info table — pull from first section (meta)
  const metaSection = sections.find(s => s.id === "meta");
  if (metaSection) {
    const metaRows = metaSection.fields.slice(0, 12).map(f => [f.label, formData[metaSection.id]?.[f.id] || ""]);
    children.push(...infoTable(metaRows, [2400, 6600]));
  }

  // ── EXECUTIVE SUMMARY ─────────────────────────────────────────────
  children.push(pageBreak(), H1("Executive Summary"), goldRule());
  if (summary) {
    children.push(H3("AI Strategic Intelligence Brief", GOLD));
    children.push(...bodyLines(summary));
    children.push(thinRule());
  }
  if (metaSection) {
    const summaryFields = metaSection.fields.filter(f =>
      f.label.toLowerCase().includes("summary") ||
      f.label.toLowerCase().includes("objective") ||
      f.label.toLowerCase().includes("positioning") ||
      f.label.toLowerCase().includes("context")
    );
    summaryFields.forEach(f => {
      const v = formData[metaSection.id]?.[f.id];
      if (v?.trim()) children.push(...labelBlock(f.label, v));
    });
  }

  // ── CORE SECTIONS ─────────────────────────────────────────────────
  for (const section of sections) {
    if (section.id === "meta") continue; // already handled
    children.push(pageBreak(), H1(section.label, NAVY), goldRule());
    if (!section.fields?.length) continue;
    for (const field of section.fields) {
      const val = formData[section.id]?.[field.id];
      if (val?.trim()) {
        children.push(...labelBlock(field.label, val, "#" + (section.color?.replace("#", "") || STEEL)));
      }
    }
  }

  // ── VERTICAL PLANS ────────────────────────────────────────────────
  for (const vert of verticals) {
    children.push(...vertBanner(vert));
    const vertColor = vert.color?.replace("#", "") || NAVY;
    // Overview table
    const overviewRows = vertFields.slice(0, 5).map(f => [f.label, formData[vert.id]?.[f.id] || ""]);
    if (overviewRows.some(([, v]) => v)) {
      children.push(...infoTable([
        ["Vertical", `${vert.label} — ${vert.fullName}`],
        ...overviewRows,
      ]));
    }
    // Remaining fields as label blocks
    for (const field of vertFields.slice(5)) {
      const val = formData[vert.id]?.[field.id];
      if (val?.trim()) children.push(...labelBlock(field.label, val, "#" + vertColor));
    }
  }

  // ── KPI FRAMEWORK ─────────────────────────────────────────────────
  if (kpiCats.length) {
    children.push(pageBreak(), H1("KPI Framework", NAVY), goldRule());
    children.push(...bodyLines("The following KPIs are linked to each sales vertical, role, and SMART goal. Track actuals weekly and review in monthly sales command meeting."));
    children.push(new Paragraph({ ...sp(200, 0) }));

    for (const cat of kpiCats) {
      if (!cat.kpis?.length) continue;
      children.push(H2(`${cat.icon || ""} ${cat.label}`, "#" + (cat.color?.replace("#", "") || STEEL)));
      children.push(...kpiTable(cat.kpis, cat.color?.replace("#", "") || NAVY));
    }
  }

  // ── SMART GOALS ───────────────────────────────────────────────────
  const rolesWithGoals = roles.filter(r => r.goals?.length);
  if (rolesWithGoals.length) {
    children.push(pageBreak(), H1("SMART Goals by Role", NAVY), goldRule());
    children.push(...bodyLines("Each goal is Specific, Measurable, Achievable, Relevant, and Time-bound — cascading from the Master Sales Plan targets."));

    for (const role of rolesWithGoals) {
      const roleColor = role.color?.replace("#", "") || NAVY;
      children.push(
        new Paragraph({
          ...sp(280, 80),
          children: [
            new TextRun({ text: role.title, bold: true, size: 24, color: "#" + roleColor, font: "Garamond" }),
            new TextRun({ text: `  [${role.band}]`, size: 19, color: SLATE, font: "Arial" }),
          ],
        }),
        new Paragraph({ ...sp(0, 100), border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: roleColor, space: 2 } }, children: [] }),
      );
      for (let i = 0; i < role.goals.length; i++) {
        const goal = role.goals[i];
        const statusKey = `${role.id}_${i}`;
        const status = goalStatus[statusKey] || "pending";
        const note = goalNotes[statusKey] || "";
        const statusColor = { pending: SLATE, in_progress: "2A80D0", achieved: "3DA863", at_risk: "C44030" }[status] || SLATE;
        children.push(
          new Paragraph({
            ...sp(160, 50),
            children: [
              new TextRun({ text: `Goal ${i + 1}  `, bold: true, size: 20, color: "#" + roleColor, font: "Arial" }),
              new TextRun({ text: `[${goal.category || "General"}]  `, size: 18, color: SLATE, font: "Arial" }),
              new TextRun({ text: status.replace("_", " ").toUpperCase(), size: 16, color: "#" + statusColor, font: "Arial" }),
            ],
          }),
          ...bodyLines(goal.goal, 240),
          new Paragraph({
            ...sp(60, 30), indent: { left: 240 },
            children: [new TextRun({ text: `Timeframe: ${goal.timeframe || "TBD"}`, size: 18, italics: true, color: SLATE, font: "Arial" })],
          }),
        );
        if (goal.linked_kpis?.length) {
          children.push(
            new Paragraph({
              ...sp(40, 80), indent: { left: 240 },
              children: [new TextRun({ text: `Linked KPIs: ${goal.linked_kpis.join("  ·  ")}`, size: 17, color: "2A80D0", font: "Arial" })],
            })
          );
        }
        if (note) children.push(...bodyLines(`Notes: ${note}`, 240));
      }
      children.push(thinRule());
    }
  }

  // ── JOB DESCRIPTIONS ──────────────────────────────────────────────
  if (roles.length) {
    children.push(pageBreak(), H1("Job Descriptions", NAVY), goldRule());
    children.push(...bodyLines("All roles link directly to the KPI framework and SMART goals. Responsibilities, requirements, and KPI linkages are fully configurable in the system."));

    for (const role of roles) {
      const roleColor = role.color?.replace("#", "") || NAVY;
      children.push(
        pageBreak(),
        new Paragraph({ ...sp(0, 0), shading: { fill: roleColor, type: ShadingType.CLEAR }, children: [new TextRun({ text: `  ${role.title}  ·  ${role.band}`, bold: true, size: 24, color: WHITE, font: "Garamond" })] }),
        new Paragraph({ ...sp(0, 160), shading: { fill: "F0F4F8", type: ShadingType.CLEAR }, children: [new TextRun({ text: "  ARD CITY  ·  JOB DESCRIPTION", size: 16, color: NAVY, font: "Arial", characterSpacing: 80 })] }),
      );
      children.push(...infoTable([
        ["Band / Level", role.band || ""],
        ["Vertical", role.vertical === "all" ? "All Verticals" : role.vertical],
      ]));
      if (role.summary) {
        children.push(
          new Paragraph({
            ...sp(120, 80), indent: { left: 200 },
            border: { left: { style: BorderStyle.SINGLE, size: 4, color: roleColor, space: 8 } },
            children: [new TextRun({ text: role.summary, size: 20, italics: true, color: SLATE, font: "Garamond" })],
          })
        );
      }
      if (role.responsibilities?.length) {
        children.push(H3("Key Responsibilities", "#" + roleColor));
        role.responsibilities.forEach((r, i) => {
          children.push(new Paragraph({
            ...sp(40, 50), indent: { left: 360 },
            children: [
              new TextRun({ text: `${i + 1}.  `, bold: true, size: 19, color: "#" + roleColor, font: "Arial" }),
              new TextRun({ text: r, size: 20, font: "Garamond", color: DGRAY }),
            ],
          }));
        });
      }
      if (role.requirements?.length) {
        children.push(H3("Requirements", "#" + roleColor));
        role.requirements.forEach(r => {
          children.push(new Paragraph({
            ...sp(40, 50), indent: { left: 360 },
            children: [
              new TextRun({ text: "•  ", size: 19, color: "#" + roleColor, font: "Arial" }),
              new TextRun({ text: r, size: 20, font: "Garamond", color: DGRAY }),
            ],
          }));
        });
      }
      if (role.kpis?.length) {
        children.push(H3("Linked KPIs", "#" + roleColor));
        children.push(new Paragraph({
          ...sp(40, 80), indent: { left: 360 },
          children: [new TextRun({ text: role.kpis.join("  ·  "), size: 19, color: "2A80D0", font: "Arial" })],
        }));
      }
    }
  }

  // ── BUILD DOCUMENT ────────────────────────────────────────────────
  const doc = new Document({
    styles: {
      default: { document: { run: { font: "Garamond", size: 22 } } },
      paragraphStyles: [
        {
          id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: 32, bold: true, font: "Garamond", color: NAVY },
          paragraph: { spacing: { before: 400, after: 160 }, outlineLevel: 0 },
        },
        {
          id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
          run: { size: 24, bold: true, font: "Garamond", color: STEEL },
          paragraph: { spacing: { before: 240, after: 100 }, outlineLevel: 1 },
        },
      ],
    },
    sections: [{
      properties: {
        page: { size: { width: 12240, height: 15840 }, margin: { top: 1200, right: 1200, bottom: 1200, left: 1200 } },
      },
      headers: {
        default: new Header({
          children: [
            new Paragraph({
              border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: GOLD, space: 4 } },
              children: [
                new TextRun({ text: "ARD CITY  ·  ", bold: true, size: 17, color: NAVY, font: "Arial", characterSpacing: 60 }),
                new TextRun({ text: planTitle, size: 17, color: SLATE, font: "Arial" }),
                new TextRun({ text: "    CONFIDENTIAL", size: 15, color: "AAAAAA", font: "Arial" }),
              ],
            }),
          ],
        }),
      },
      footers: {
        default: new Footer({
          children: [
            new Paragraph({
              border: { top: { style: BorderStyle.SINGLE, size: 2, color: "CCCCCC", space: 4 } },
              children: [
                new TextRun({ text: "ARD City Sales Intelligence System", size: 15, color: "888888", font: "Arial" }),
                new TextRun({ text: "   ·   All Rights Reserved", size: 15, color: "AAAAAA", font: "Arial" }),
              ],
            }),
          ],
        }),
      },
      children: children.filter(Boolean),
    }],
  });

  return await Packer.toBuffer(doc);
}
