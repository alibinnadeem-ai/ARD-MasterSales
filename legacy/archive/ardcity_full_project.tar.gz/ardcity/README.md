# 🏙 ARD City — Sales Intelligence Command System

> Complete full-stack sales intelligence platform: Master Sales Plan + KPI Dashboard + SMART Goals + Job Descriptions. Fully dynamic — every field, section, vertical, KPI, goal, and JD is add/edit/remove capable. Generates branded DOCX and PDF exports.

---

## Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18 + Vite |
| Backend | Node.js 22 + Express |
| PDF Generation | Python 3 + ReportLab |
| DOCX Generation | docx.js (Node) |
| AI | Anthropic Claude claude-sonnet-4-20250514 |
| Deployment | Docker + Nginx |

---

## Quick Start (Development)

### Prerequisites
- Node.js 18+ and npm
- Python 3.10+ with pip
- An Anthropic API key (for AI features)

### 1. Clone and install

```bash
git clone <repo-url>
cd ardcity

# Backend
cd backend
npm install
pip install reportlab

# Frontend
cd ../frontend
npm install
```

### 2. Configure environment

```bash
cd ../backend
cp .env.example .env
# Edit .env and add your ANTHROPIC_API_KEY
```

### 3. Start development servers

**Terminal 1 — Backend:**
```bash
cd backend
npm run dev
# API running at http://localhost:3001
```

**Terminal 2 — Frontend:**
```bash
cd frontend
npm run dev
# App running at http://localhost:5173
```

Open **http://localhost:5173** in your browser.

---

## Production Deployment

### Option A: Docker Compose (Recommended)

```bash
# 1. Set environment variables
cp .env.example .env
nano .env  # Add ANTHROPIC_API_KEY

# 2. Build and start
docker-compose up -d --build

# 3. Check health
curl http://localhost/api/health
```

Access the app at **http://localhost** (port 80).

### Option B: Manual Production Build

```bash
# Build frontend
cd frontend
npm run build

# Start backend (serves built frontend as static files)
cd ../backend
NODE_ENV=production npm start
```

Access at **http://localhost:3001**

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/health` | Health check |
| `POST` | `/api/ard-generate?type=docx` | Generate Word document |
| `POST` | `/api/ard-generate?type=pdf` | Generate PDF document |
| `POST` | `/api/save` | Save plan to disk |
| `GET` | `/api/load/:id` | Load saved plan |
| `GET` | `/api/plans` | List all saved plans |
| `DELETE` | `/api/plans/:id` | Delete a plan |
| `POST` | `/api/ai-review` | AI strategic review (server-side key) |

### Document Generation Payload

```json
{
  "formData": { "meta": {}, "b2g": {}, ... },
  "sections": [ { "id": "...", "label": "...", "fields": [...] } ],
  "verticals": [ { "id": "b2g", "label": "B2G", "color": "#1A6BB5", ... } ],
  "vertFields": [ { "id": "...", "label": "Objective", "type": "text" } ],
  "kpiCats": [ { "id": "...", "label": "Revenue KPIs", "kpis": [...] } ],
  "roles": [ { "id": "...", "title": "VP Sales", "goals": [...], ... } ],
  "goalStatus": { "roleId_0": "achieved" },
  "goalNotes": { "roleId_0": "On track as of Q1" },
  "summary": "AI-generated executive summary..."
}
```

---

## Project Structure

```
ardcity/
├── backend/
│   ├── server.js              # Express API server (document gen + save/load)
│   ├── generators/
│   │   └── pdf_generator.py   # Dynamic ReportLab PDF generator
│   ├── data/                  # Saved plan JSON files
│   ├── temp/                  # Temporary generated files (auto-cleaned)
│   ├── package.json
│   └── .env
├── frontend/
│   ├── src/
│   │   ├── main.jsx           # React entry point
│   │   ├── App.jsx            # Complete Sales Intelligence System UI
│   │   └── api.js             # API service layer
│   ├── public/
│   │   └── favicon.svg
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── docker/
│   └── nginx.conf             # Nginx reverse proxy config
├── Dockerfile.backend
├── Dockerfile.frontend
├── docker-compose.yml
├── .env.example
├── .gitignore
└── README.md
```

---

## Features

### Sales Plan (Fully Dynamic)
- 6 pre-built core sections (Plan Overview, Product Release, Timeline, Budget, Events, Marketing)
- 5 pre-built sales verticals (B2G, B2C, B2B, Channel Partners, Overseas/Diaspora)
- **Add/remove/rename sections and verticals**
- **Add/remove/rename fields** within any section — toggle single-line vs multi-line
- Per-section completion tracking with animated progress bars
- Save & Next navigation flow
- Section-level AI review

### KPI Dashboard
- 4 pre-built categories (Revenue, Pipeline, Activity, Quality) with 22 KPIs
- **Add/remove KPI categories and individual KPIs**
- **Edit all KPI properties** (label, target, unit, frequency, vertical, role)
- Live Actual tracking — click any KPI to enter current actuals

### SMART Goals
- **Add/remove roles** with full inline editing (title, band, vertical, color)
- **Add/remove goals** per role — expand to edit goal text, category, timeframe
- **Tag-style linked KPIs** — add/remove individually
- Status tracking (Pending → In Progress → Achieved ✓ → At Risk ⚠)
- Progress notes per goal

### Job Descriptions (10 pre-built + add more)
- **Add/remove roles** — full JD editor inline
- **Tag-style responsibilities** — press Enter or + to add, × to remove
- **Tag-style requirements** — same system
- **Tag-style linked KPIs** — same system
- Accent color picker per role
- Filter by vertical

### Export
- **DOCX**: Garamond typography, ARD City navy/gold branding, running headers/footers, all sections dynamic
- **PDF**: ReportLab, print-ready, vertical banners, KPI tables, role banners, same branding

---

## Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `PORT` | No | `3001` | Backend server port |
| `NODE_ENV` | No | `development` | `development` or `production` |
| `FRONTEND_URL` | No | `http://localhost:5173` | Allowed CORS origin |
| `ANTHROPIC_API_KEY` | No | — | Enables AI review + auto-summary in exports |
| `DATA_DIR` | No | `./data` | Directory for saved plan JSON files |

---

## Scaling Notes

- **Data persistence**: Currently file-based JSON in `backend/data/`. For multi-user production, swap with PostgreSQL or MongoDB using the same API interface.
- **AI**: Server-side key configured via `ANTHROPIC_API_KEY`. Without it, AI features use client-side (browser) calls if the UI still has them, or are gracefully disabled.
- **Document generation**: DOCX runs in-process in Node.js. PDF spawns a Python child process. Both are synchronous per request — fine for moderate load. For high volume, queue with Bull/BullMQ.

---

*Built by CyberX Inc. for ARD City / Eurobiz Corporation*  
*Technology: Ali Bin Nadeem, CTO — CyberX Inc.*
