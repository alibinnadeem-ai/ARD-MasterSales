/**
 * ARD City — API Service Layer
 * All backend communication goes through here
 */

const BASE = "/api";

export const api = {
  // Document generation
  async generate(type, payload) {
    const res = await fetch(`${BASE}/ard-generate?type=${type}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: "Generation failed" }));
      throw new Error(err.error || "Generation failed");
    }
    return res.blob();
  },

  // Save plan
  async save(planData, name) {
    const res = await fetch(`${BASE}/save`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...planData, name }),
    });
    return res.json();
  },

  // Load plan
  async load(id) {
    const res = await fetch(`${BASE}/load/${id}`);
    if (!res.ok) throw new Error("Plan not found");
    return res.json();
  },

  // List all saved plans
  async listPlans() {
    const res = await fetch(`${BASE}/plans`);
    return res.json();
  },

  // Delete plan
  async deletePlan(id) {
    const res = await fetch(`${BASE}/plans/${id}`, { method: "DELETE" });
    return res.json();
  },

  // AI Review (server-side key)
  async aiReview(content) {
    const res = await fetch(`${BASE}/ai-review`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
    });
    return res.json();
  },

  // Health check
  async health() {
    const res = await fetch(`${BASE}/health`);
    return res.json();
  },
};
